
import sys
from resources.lib.functions import *

if len(sys.argv) > 1:
    if sys.argv[1] == 'refresh':
        refresh()