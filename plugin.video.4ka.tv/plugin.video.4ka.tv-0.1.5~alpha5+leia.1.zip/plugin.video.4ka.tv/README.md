Plugin for generate playlist and EPG XMLTv list for 4KA TV service

Video addon lay live stream from 4KA TV serevice

This plugin can be installed from repo (https://github.com/kkjan/kkjan-kodi-repo) or by zip file from https://github.com/kkjan/kkjan-kodi-repo/plugin.video.plugin.video.4ka.tv